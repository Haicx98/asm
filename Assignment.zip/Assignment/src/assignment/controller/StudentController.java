/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.controller;

import assignment.entity.Student;
import assignment.model.StudentModel;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Haicx
 */
public class StudentController {

    private StudentModel model = new StudentModel();

    public void printStudentList() {
        ArrayList<Student> list = model.getListStudent();
        System.out.println("=========Student List=========");
        System.out.println("name \t id ");
        for (int i = 0; i < list.size(); i++) {
            Student student = list.get(i);
            System.out.println(student.getName() + "\t" + student.getId());
        }
        System.out.println("======================");
    }

    public void addStudent() {
        Student student = new Student();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Please enter your name: ");
            String value = scanner.nextLine();
            if (value != null && value.length() > 5) {
                student.setName(value);
                break;
            }
            System.out.println("Name is invalid please try again");
        }
        while (true) {
            System.out.println("Please enter your roll number : ");
            String value = scanner.nextLine();
            if (value != null && value.length() > 5) {
                student.setRollNumber(value);
                break;
            }
            System.out.println("Roll number is invalid please try again");
        }
        while (true) {
            System.out.println("Please enter your phone: ");
            String value = scanner.nextLine();
            if (value != null && value.length() > 5) {
                student.setPhone(value);
                break;
            }
            System.out.println("Phone number is invalid please try again");
        }
        while (true) {
            System.out.println("Please enter your email: ");
            String value = scanner.nextLine();
            if (value != null && value.length() > 5) {
                student.setEmail(value);
                break;
            }
            System.out.println("Email is invalid please try again");
        }
        model.insert(student);
        System.out.println("Student has been added to system.");
        System.out.println("==========================");
    }

    public void editStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("===========Edit Student==========");
        System.out.println("Please enter student id : ");
        int id = scanner.nextInt();
        scanner.nextLine();
        Student existStudent = model.getStudentById(id);
        if (existStudent == null) {
            System.out.println("Student does not exist or has been deleted");
        } else {
            System.out.println("Student information: ");
            System.out.println("Id : " + existStudent.getId());
            System.out.println("rollNumber : " + existStudent.getRollNumber());
            System.out.println("name : " + existStudent.getName());
            System.out.println("Phone : " + existStudent.getPhone());
            System.out.println("Email : " + existStudent.getEmail());
            System.out.println("--------------------------------");
            System.out.println("Please enter new name : ");
            String name = scanner.nextLine();
            System.out.println("Please enter new rollNumber : ");
            String rollNumber = scanner.nextLine();
            System.out.println("Please enter new phone number: ");
            String phone = scanner.nextLine();
            System.out.println("Please enter new email : ");
            String email = scanner.nextLine();

            existStudent.setName(name);
            existStudent.setRollNumber(rollNumber);
            existStudent.setPhone(phone);
            existStudent.setEmail(email);
            model.update(existStudent);
            System.out.println("===========Student has been updated============");
        }
    }

    public void deleteStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("===========Delete Student==========");
        System.out.println("Please enter student id : ");
        int id = scanner.nextInt();
        scanner.nextLine();
        Student existStudent = model.getStudentById(id);
        if (existStudent == null) {
            System.out.println("Student does not exist or has been deleted");
        } else {
            System.out.println("Student information: ");
            System.out.println("Id : " + existStudent.getId());
            System.out.println("rollNumber : " + existStudent.getRollNumber());
            System.out.println("name : " + existStudent.getName());
            System.out.println("Phone : " + existStudent.getPhone());
            System.out.println("Email : " + existStudent.getEmail());
            System.out.println("--------------------------------");
            model.delete(existStudent);
            System.out.println("Student has been deleted from system.");
        }
    }

}
