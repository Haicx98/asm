/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.model;

import assignment.entity.Student;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Haicx
 */
public class StudentModel {

    public ArrayList<Student> getListStudent() {
        ArrayList<Student> studentList = new ArrayList<>();
        try {
            Connection connection = ConnectionHelper.getConnection();
            if (connection == null) {
                return studentList;
            }
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT*FROM students");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String rollNumber = rs.getString("rollNumber");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                int status = rs.getInt("status");
                Student student = new Student(name, rollNumber, email, phone, id, status);
                studentList.add(student);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return studentList;
    }

    public boolean insert(Student student) {
        String sql = "insert into students(rollNumber,name,phone,email) values(?,?,?,?)";
        Connection connection = ConnectionHelper.getConnection();
        if (connection == null) {
            return false;
        }
        try {
            PreparedStatement pS = connection.prepareStatement(sql);
            pS.setString(1, student.getRollNumber());
            pS.setString(2, student.getName());
            pS.setString(3, student.getPhone());
            pS.setString(4, student.getEmail());
            pS.execute();
        } catch (SQLException ex) {
            Logger.getLogger(StudentModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public Student getStudentById(int id) {
        Connection connection = ConnectionHelper.getConnection();
        Student student = null;
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("select*from students where id = " + id);
            while (rs.next()) {
                int studentId = rs.getInt("id");
                String name = rs.getString("name");
                String rollNumber = rs.getString("rollNumber");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                int status = rs.getInt("status");
                student = new Student(name, rollNumber, email, phone, studentId, status);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return student;
    }

    public boolean update(Student student){
        Connection connection = ConnectionHelper.getConnection();
        String sql = "update students set rollNumber = ?,name = ?,phone = ?,email = ? where id = ?";
        if(connection == null){
            return false;
        }
        try {
            PreparedStatement pS = connection.prepareStatement(sql);
            pS.setString(1, student.getRollNumber());
            pS.setString(2, student.getName());
            pS.setString(3, student.getPhone());
            pS.setString(4, student.getEmail());
            pS.setInt(5, student.getId());
            pS.execute();
        } catch (SQLException ex) {
            Logger.getLogger(StudentModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean delete(Student student){
        try {
            Connection connection = ConnectionHelper.getConnection();
            if(connection == null){
                return false;
            }
            PreparedStatement pS = connection.prepareStatement("delete from students where id = ?");
            pS.setInt(1, student.getId());
            pS.execute();
        } catch (SQLException ex) {
            Logger.getLogger(StudentModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
       
    }
}
